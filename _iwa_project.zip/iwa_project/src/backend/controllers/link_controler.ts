import { Router, Request, Response } from "express";
import { getVoteRepository } from "../repositories/vote_repository";
import { getRepository } from "../repositories/link_repository";
import { Repository } from "typeorm";
import { Vote } from "../entities/vote";
import { Link } from "../entities/link";
import { authMiddleware } from "../middleware/auth_middleware";

export function getHandlers( _voteRepository: Repository<Vote>, _linkRepository: Repository<Link>) {
    
    const getAllLinksHandler = (req: Request, res: Response) => {
        (async () => {
            const links = await _linkRepository.find();
            res.json(links).send();
        })();
    };
	
	const linkCreator = (req: Request, res: Response) => {
	(async () => {
            const user = (req as any).userId;
            const title = req.body.title;
            const url = req.body.url;
            if (!title || !url || !user) {
                res.status(400).send();
            } else {
                const newLink = await _linkRepository.save({ user: user, title: title, url: url });
                return res.json(newLink);
            }            
        })();
    };

   

    const deleteLink =  (req: Request, res: Response) => {
        // TODO
        res.json({});
    };

    return {
        getAllLinksHandler,
        linkCreator,
		deleteLink
    };

}

export function getLinkRouter() {
    const handlers = getHandlers(getRepository(), getVoteRepository());
    const linkRouter = Router();
    linkRouter.get("/", handlers.getAllLinksHandler); // public
	linkRouter.post("/", authMiddleware, handlers.linkCreator); // private
    linkRouter.delete("/:id", authMiddleware, handlers.deleteLink); // private
    return movieRouter;
}
