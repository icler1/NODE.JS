import { Router, Request, Response } from "express";
import { getRepository } from "../repositories/user_repository";
import { Repository } from "typeorm";
import { User } from "../entities/user";
import { authMiddleware } from "../middleware/auth_middleware";

export function getHandlers(_userRepository: Repository<User>) {
    
    const getUserByEmailHandler = (req: Request, res: Response) => {
        const email = req.body.email;
        const user = _userRepository.findOne({
            where: {
                email: email
            }
        });
        if (user === undefined) {
            res.status(404).send();
        }
        res.json(user).send();
    };
	
	const userCreator = (req: Request, res: Response) => {
        (async () => {
            const email= req.body.email;
            const password = req.body.password;
            if (!email || !password ) {
                res.status(400).send();
            } else {
                 const newUser = await _userRepository.save({ email: email, password: password});
                    return res.json(newUser);
                }
        })();
    };

    return {
		getUserByEmailHandler,
        userCreator
		
    };

}

export function getUserRouter() {
    const handlers = getHandlers(getRepository());
    const userRouter = Router();

    userRouter.post("/", handlers.userCreator); // public
    movieRouter.get("/:email", handlers.getUserByEmailHandler); // public
    return userRouter;
}
