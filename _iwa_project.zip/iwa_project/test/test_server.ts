var chai = require('chai')
  , chaiHttp = require('chai-http');

chai.use(chaiHttp);